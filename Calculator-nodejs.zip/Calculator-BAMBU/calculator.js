const express = require('express')
const app = express()
var bodyParser = require('body-parser')

app.listen(3000,function(){
    console.log("SERVER STARTED RUNNING ON PORT 3000");
})

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.get("/",function(req,res){
    res.sendFile(__dirname+"/index.html")
})
app.post("/",function(req,res){
    var n1= Number(req.body.n1);
    var n2=Number(req.body.n2);
    var result=n1+n2;
    res.send("Result="+result);
})